package servicos;

import entidades.Participante;

public interface IServicoParticipante extends ServicoInterface<Participante> {
}
