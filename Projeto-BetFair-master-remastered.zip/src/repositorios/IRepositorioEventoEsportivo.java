package repositorios;

import entidades.EventoEsportivo;

/**
 * Interface específica para Repositório de EventoEsportivo.
 * Estende a interface genérica RepositorioInterface<EventoEsportivo>.
 */
public interface IRepositorioEventoEsportivo extends RepositorioInterface<EventoEsportivo> {
}
