package repositorios;

import entidades.Aposta;

/**
 * Interface específica para Repositório de Aposta.
 * Estende a interface genérica RepositorioInterface<Aposta>.
 */
public interface IRepositorioAposta extends RepositorioInterface<Aposta> {
}
