package servicos;

import entidades.EventoEsportivo;

/**
 * Interface específica para serviço de EventoEsportivo.
 * Estende a interface genérica ServicoInterface<EventoEsportivo>.
 */
public interface IServicoEventoEsportivo extends ServicoInterface<EventoEsportivo> {
}
