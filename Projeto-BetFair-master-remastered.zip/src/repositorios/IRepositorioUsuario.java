package repositorios;

import entidades.Usuario;

/**
 * Interface específica para Repositório de Usuario.
 */
public interface IRepositorioUsuario extends RepositorioInterface<Usuario> {
}
