package servicos;

import entidades.Carteira;

/**
 * Interface específica para serviço de Carteira.
 * Estende a interface genérica ServicoInterface<Carteira>.
 */
public interface IServicoCarteira extends ServicoInterface<Carteira> {
}
